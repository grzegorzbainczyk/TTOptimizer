#include "Optimization/GeneticOptimizer.h"

#include <algorithm>
#include <chrono>
#include <future>
#include <iostream>
#include <stdexcept>
#include <utility>
#include <thread>

#include "Evaluation/Validation/ChromosomeValidator.h"

GeneticOptimizer::GeneticOptimizer(const OptimizationSettings& settings, ProgressCallback progressCallback)
    : settings(settings), progressCallback(std::move(progressCallback)), chromosomeFactory(settings.randomSeed), mutator(settings.randomSeed), randomEngine(settings.randomSeed),
    threadPool(std::max(1u, std::thread::hardware_concurrency()))
{
}

std::vector<Chromosome> GeneticOptimizer::createInitialPopulation(const TimetableProblem& problem, const std::vector<LessonInstance>& lessonInstances,
    const std::vector<ScheduleSlot>& scheduleSlots)
{
    const int populationSize = settings.populationSize;

    if (populationSize <= 0)
    {
        throw std::invalid_argument("Population size must be greater than zero.");
    }

    std::vector<Chromosome> population;
    population.reserve(static_cast<std::size_t>(populationSize));

    // Build independent random timetable candidates first, then evaluate the whole batch through the persistent thread pool.
    for (int index = 0; index < populationSize; ++index)
    {
        population.push_back(chromosomeFactory.createRandom(scheduleSlots, lessonInstances));
    }

    evaluatePopulation(population, problem, lessonInstances, scheduleSlots);
    return population;
}

Chromosome GeneticOptimizer::optimize(std::vector<Chromosome> initialPopulation, const TimetableProblem& problem, const std::vector<LessonInstance>& lessonInstances,
    const std::vector<ScheduleSlot>& scheduleSlots)
{
    // Keep this method at the level of the genetic algorithm itself. Detailed operations
    // are delegated to smaller methods, so this function can be read almost like pseudocode.
    validateOptimizationInput(initialPopulation, lessonInstances, scheduleSlots);

    std::vector<Chromosome> population = initializePopulation(std::move(initialPopulation), problem, lessonInstances, scheduleSlots);

    // initializePopulation() returns a sorted population, so front() is the initial best.
    Chromosome bestChromosome = population.front();
    int bestFoundAtGeneration = 0;
    int lastReportedPercentage = -1;

    reportInitialState(bestChromosome);
    reportProgress(0, settings.generations, bestFoundAtGeneration, bestChromosome, lastReportedPercentage);

    // Each iteration creates one complete generation. createNextGeneration() returns it sorted.
    for (int generation = 1; generation <= settings.generations; ++generation)
    {
        population = createNextGeneration(population, problem, lessonInstances, scheduleSlots);

        updateBestChromosome(population, bestChromosome, generation, bestFoundAtGeneration);
        reportProgress(generation, settings.generations, bestFoundAtGeneration, bestChromosome, lastReportedPercentage);

        if (shouldStopEarly(bestChromosome))
        {
            reportPerfectSolution(generation);
            break;
        }
    }

    // Final consistency check: recalculate fitness against the current problem and rules.
    bestChromosome.fitness = fitnessEvaluator.evaluate(bestChromosome, problem, lessonInstances, scheduleSlots);

    return bestChromosome;
}

void GeneticOptimizer::validateOptimizationInput(
    const std::vector<Chromosome>& initialPopulation,
    const std::vector<LessonInstance>& lessonInstances,
    const std::vector<ScheduleSlot>& scheduleSlots) const
{
    if (settings.generations <= 0)
    {
        throw std::invalid_argument("Generations must be greater than zero.");
    }

    if (initialPopulation.empty())
    {
        throw std::invalid_argument("Initial population cannot be empty.");
    }

    if (scheduleSlots.empty() && !lessonInstances.empty())
    {
        throw std::invalid_argument(
            "Schedule slots cannot be empty when lesson instances exist.");
    }

    const int populationSize = static_cast<int>(initialPopulation.size());

    if (settings.eliteCount < 0 || settings.eliteCount >= populationSize)
    {
        throw std::invalid_argument(
            "Elite count must be non-negative and smaller than population size.");
    }

    if (settings.tournamentSize <= 0 || settings.tournamentSize > populationSize)
    {
        throw std::invalid_argument("Tournament size must be between 1 and population size.");
    }

    if (settings.mutationAttempts < 0)
    {
        throw std::invalid_argument("Mutation attempts cannot be negative.");
    }

    if (settings.mutationProbability < 0.0 || settings.mutationProbability > 1.0)
    {
        throw std::invalid_argument("Mutation probability must be between 0.0 and 1.0.");
    }
}

std::vector<Chromosome> GeneticOptimizer::initializePopulation(
    std::vector<Chromosome> population,
    const TimetableProblem& problem,
    const std::vector<LessonInstance>& lessonInstances,
    const std::vector<ScheduleSlot>& scheduleSlots)
{
    // Re-evaluate the population against exactly the data used by this optimization run.
    evaluatePopulation(population, problem, lessonInstances, scheduleSlots);

    // Contract: every population leaving this method is sorted from best to worst.
    sortPopulation(population);
    return population;
}

std::vector<Chromosome> GeneticOptimizer::createNextGeneration(
    const std::vector<Chromosome>& population,
    const TimetableProblem& problem,
    const std::vector<LessonInstance>& lessonInstances,
    const std::vector<ScheduleSlot>& scheduleSlots)
{
    const std::size_t populationSize = population.size();

    std::vector<Chromosome> nextPopulation;
    nextPopulation.reserve(populationSize);

    // Elitism protects the strongest chromosomes from random selection and mutation.
    copyElite(population, nextPopulation);

    // Fill the remaining positions with children created from tournament-selected parents.
    while (nextPopulation.size() < populationSize)
    {
        Chromosome child = createChild(population, problem, lessonInstances, scheduleSlots);
        nextPopulation.push_back(std::move(child));
    }

    // Contract: every completed generation is sorted from best to worst.
    sortPopulation(nextPopulation);
    return nextPopulation;
}

void GeneticOptimizer::copyElite(
    const std::vector<Chromosome>& population,
    std::vector<Chromosome>& nextPopulation) const
{
    for (int index = 0; index < settings.eliteCount; ++index)
    {
        nextPopulation.push_back(population[static_cast<std::size_t>(index)]);
    }
}

Chromosome GeneticOptimizer::createChild(
    const std::vector<Chromosome>& population,
    const TimetableProblem& problem,
    const std::vector<LessonInstance>& lessonInstances,
    const std::vector<ScheduleSlot>& scheduleSlots)
{
    const Chromosome& parent = selectByTournament(population);

    // If mutation is skipped, the selected parent survives unchanged as the child.
    std::bernoulli_distribution mutationDistribution(settings.mutationProbability);

    if (!mutationDistribution(randomEngine))
    {
        return parent;
    }

    return findBestMutation(parent, problem, lessonInstances, scheduleSlots);
}

Chromosome GeneticOptimizer::findBestMutation(const Chromosome& parent, const TimetableProblem& problem, const std::vector<LessonInstance>& lessonInstances,
    const std::vector<ScheduleSlot>& scheduleSlots)
{
    Chromosome bestCandidate = parent;

    if (settings.mutationAttempts <= 0)
    {
        return bestCandidate;
    }

    // Generate seeds on the optimizer thread. Every task then gets its own RNG, so std::mt19937 is never shared between workers.
    std::vector<unsigned int> seeds(static_cast<std::size_t>(settings.mutationAttempts));

    for (unsigned int& seed : seeds)
    {
        seed = randomEngine();
    }

    std::vector<std::future<Chromosome>> futures;
    futures.reserve(seeds.size());

    for (const unsigned int seed : seeds)
    {
        futures.push_back(threadPool.enqueue([this, &parent, &problem, &lessonInstances, &scheduleSlots, seed]()
        {
            std::mt19937 localRandomEngine(seed);
            Chromosome candidate = parent;

            mutator.mutateAssignment(candidate, scheduleSlots.size(), localRandomEngine);
            candidate.fitness = fitnessEvaluator.evaluate(candidate, problem, lessonInstances, scheduleSlots);

            return candidate;
        }));
    }

    for (std::future<Chromosome>& future : futures)
    {
        Chromosome candidate = future.get();

        if (candidate.fitness.isBetterThan(bestCandidate.fitness))
        {
            bestCandidate = std::move(candidate);
        }
    }

    return bestCandidate;
}

void GeneticOptimizer::updateBestChromosome(
    const std::vector<Chromosome>& population,
    Chromosome& bestChromosome,
    int generation,
    int& bestFoundAtGeneration) const
{
    // createNextGeneration() returns a sorted population, so front() is this generation's best.
    const Chromosome& generationBest = population.front();

    if (!generationBest.fitness.isBetterThan(bestChromosome.fitness))
    {
        return;
    }

    bestChromosome = generationBest;
    bestFoundAtGeneration = generation;

    std::cerr << "Generation: " << generation
        << ", new best: hard violations = " << bestChromosome.fitness.hardViolationCount
        << ", soft penalty = " << bestChromosome.fitness.softPenalty << '\n';
}

bool GeneticOptimizer::shouldStopEarly(const Chromosome& bestChromosome) const
{
    // A feasible solution with zero soft penalty cannot improve under the current fitness model.
    return settings.stopWhenPerfect
        && bestChromosome.fitness.isFeasible()
        && bestChromosome.fitness.softPenalty == 0.0;
}

void GeneticOptimizer::reportInitialState(const Chromosome& bestChromosome)
{
    std::cerr << "Initial population best: hard violations = "
        << bestChromosome.fitness.hardViolationCount
        << ", soft penalty = " << bestChromosome.fitness.softPenalty << '\n';
}

void GeneticOptimizer::reportPerfectSolution(int generation)
{
    std::cerr << "Perfect solution found in generation " << generation << ".\n";
}

void GeneticOptimizer::reportProgress(
    int generation,
    int totalGenerations,
    int bestFoundAtGeneration,
    const Chromosome& bestChromosome,
    int& lastReportedPercentage) const
{
    if (!progressCallback)
    {
        return;
    }

    const int percentage = generation * 100 / totalGenerations;

    if (percentage == lastReportedPercentage)
    {
        return;
    }

    OptimizationProgress progress;
    progress.generation = generation;
    progress.totalGenerations = totalGenerations;
    progress.percentage = percentage;
    progress.bestFoundAtGeneration = bestFoundAtGeneration;
    progress.best.hardViolationCount = bestChromosome.fitness.hardViolationCount;
    progress.best.softPenalty = bestChromosome.fitness.softPenalty;

    progressCallback(progress);
    lastReportedPercentage = percentage;
}

void GeneticOptimizer::evaluatePopulation(std::vector<Chromosome>& population, const TimetableProblem& problem, const std::vector<LessonInstance>& lessonInstances,
    const std::vector<ScheduleSlot>& scheduleSlots)
{
    if (population.empty())
    {
        return;
    }

    // -------------------------------------------------------------------------
    // Single-threaded
    // -------------------------------------------------------------------------

   /* const auto singleStart = std::chrono::steady_clock::now();

    for (Chromosome& chromosome : population)
    {
        ChromosomeValidator::validate(chromosome, lessonInstances, scheduleSlots);
        chromosome.fitness = fitnessEvaluator.evaluate(chromosome, problem, lessonInstances, scheduleSlots);
    }

    const auto singleEnd = std::chrono::steady_clock::now();
    const auto singleDuration = std::chrono::duration_cast<std::chrono::microseconds>(singleEnd - singleStart);*/

    // -------------------------------------------------------------------------
    // Thread pool
    // -------------------------------------------------------------------------

    const auto poolStart = std::chrono::steady_clock::now();

    const std::size_t taskCount = std::min(threadPool.size(), population.size());
    const std::size_t chunkSize = (population.size() + taskCount - 1) / taskCount;

    std::vector<std::future<void>> futures;
    futures.reserve(taskCount);

    for (std::size_t taskIndex = 0; taskIndex < taskCount; ++taskIndex)
    {
        const std::size_t begin = taskIndex * chunkSize;
        const std::size_t end = std::min(begin + chunkSize, population.size());

        if (begin >= end)
        {
            break;
        }

        futures.push_back(threadPool.enqueue([this, &population, &problem, &lessonInstances, &scheduleSlots, begin, end]()
            {
                for (std::size_t index = begin; index < end; ++index)
                {
                    Chromosome& chromosome = population[index];
                    ChromosomeValidator::validate(chromosome, lessonInstances, scheduleSlots);
                    chromosome.fitness = fitnessEvaluator.evaluate(chromosome, problem, lessonInstances, scheduleSlots);
                }
            }));
    }

    for (std::future<void>& future : futures)
    {
        future.get();
    }

    const auto poolEnd = std::chrono::steady_clock::now();
    const auto poolDuration = std::chrono::duration_cast<std::chrono::microseconds>(poolEnd - poolStart);

    // -------------------------------------------------------------------------
    // Benchmark
    // -------------------------------------------------------------------------

   /* std::cout << "Population: " << population.size()
        << ", workers: " << threadPool.size()
        << ", single-threaded: " << singleDuration.count() << " us"
        << ", thread-pool: " << poolDuration.count() << " us";

    if (poolDuration.count() > 0)
    {
        const double speedup = static_cast<double>(singleDuration.count()) / static_cast<double>(poolDuration.count());
        std::cout << ", speedup: " << speedup << "x";
    }

    std::cout << '\n';*/
}

void GeneticOptimizer::sortPopulation(std::vector<Chromosome>& population)
{
    std::sort(population.begin(), population.end(), isBetter);
}

const Chromosome& GeneticOptimizer::selectByTournament(const std::vector<Chromosome>& population)
{
    const int tournamentSize = settings.tournamentSize;
    std::uniform_int_distribution<std::size_t> distribution(0, population.size() - 1);

    const Chromosome* winner = &population[distribution(randomEngine)];

    for (int index = 1; index < tournamentSize; ++index)
    {
        const Chromosome& competitor = population[distribution(randomEngine)];

        if (competitor.fitness.isBetterThan(winner->fitness))
        {
            winner = &competitor;
        }
    }

    return *winner;
}

bool GeneticOptimizer::isBetter(const Chromosome& first, const Chromosome& second)
{
    return first.fitness.isBetterThan(second.fitness);
}
